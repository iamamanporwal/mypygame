import pygame
import random
import math

# Intialize the pygame
pygame.init()

# create the screen
screen = pygame.display.set_mode((800,500))

#caption
pygame.display.set_caption('KILL EM HAHHA')

#load images
gun = pygame.image.load('gun.png')
gunX = 340
gunY = 350
gun_change = 0

#BTS
gay = pygame.image.load('1.png')
gayX = random.randint(50,100)
gayY = random.randint(50,300)
gay_xchange = 3
gay_ychange = 0

gay2 = pygame.image.load('2.png')
gay2X = random.randint(150,200)
gay2Y = random.randint(50,300)
gay2_xchange = 3
gay2_ychange = 0

gay3 = pygame.image.load('3.png')
gay3X = random.randint(250,300)
gay3Y = random.randint(50,300)
gay3_xchange = 3
gay3_ychange = 0

gay4 = pygame.image.load('4.png')
gay4X = random.randint(350,400)
gay4Y = random.randint(50,300)
gay4_xchange = 3
gay4_ychange = 0

gay5 = pygame.image.load('5.png')
gay5X = random.randint(450,500)
gay5Y = random.randint(50,300)
gay5_xchange = 3
gay5_ychange = 0

gay6 = pygame.image.load('6.png')
gay6X = random.randint(550,600)
gay6Y = random.randint(50,300)
gay6_xchange = 3
gay5_ychange = 0

gay7 = pygame.image.load('7.png')
gay7X = random.randint(650,700)
gay7Y = random.randint(50,300)
gay7_xchange = 3
gay7_ychange = 0

#Bullet
bullet = pygame.image.load('bullet.png')
bulletX = 0
bulletY = 390
bulletX_change = 0
bulletY_change = 20
bullet_state = "ready"

def bulletgay():
  global bullet_state
  bullet_state = "fire"
  
def collision(gayX,gayY,bulletX,bulletY):
  distance = math.sqrt(math.pow(gayX-bulletX,2)+(math.pow(gayY-bulletY,2)))
  if distance < 75:
    return True
  else:
     return False

  



stall = pygame.image.load('stall.png')
bg = pygame.image.load('background.png')


#game loop
running = False
while not running:
 for event in pygame.event.get():
    if event.type == pygame.QUIT:
      running = True

 #gun keystrokes
    if event.type == pygame.KEYDOWN: 
      if event.key == pygame.K_LEFT:
        gun_change =- 5
      if event.key == pygame.K_RIGHT:
        gun_change = 5
      if event.key == pygame.K_SPACE:
        if bullet_state is "ready":
          bulletX = gunX
          bulletgay()
      

 
      

    if event.type == pygame.KEYUP:
      if event.key==pygame.K_RIGHT or event.key==pygame.K_LEFT:
        gun_change = 0
    
 #bullet

 #BOREDERS
 gunX += gun_change
 if gunX <= -75:
   gunX = -75
 elif gunX >= 725:
   gunX = 725
 
 gayX += gay_xchange
 if gayX <= -65:
   gay_xchange = 3
 elif gayX >= 650:
   gay_xchange = -3
  
 gay2X += gay2_xchange
 if gay2X <= -65:
   gay2_xchange = 3
 elif gay2X >= 650:
   gay2_xchange = -3

 gay3X += gay3_xchange
 if gay3X <= -65:
   gay3_xchange = 3
 elif gay3X >= 650:
   gay3_xchange = -3

 gay4X += gay4_xchange
 if gay4X <= -65:
   gay4_xchange = 3
 elif gay4X >= 650:
   gay4_xchange = -3 

 gay5X += gay5_xchange
 if gay5X <= -65:
   gay5_xchange = 3
 elif gay5X >= 650:
   gay5_xchange = -3 
  
 gay6X += gay6_xchange
 if gay6X <= -65:
   gay6_xchange = 3
 elif gay6X >= 650:
   gay6_xchange = -3

 gay7X += gay7_xchange
 if gay7X <= -65:
   gay7_xchange = 3
 elif gay7X >= 650:
   gay7_xchange = -3

 #bg image
 screen.blit(bg,(0,0))
     
 #bts ki gang
 screen.blit(gay,(gayX,gayY))
 
 

 #stall layer image
 screen.blit(stall,(0,10))

 #bullet
 screen.blit(bullet,(bulletX+59,bulletY+20))
 if bulletY <= 0:
   bulletY = 480
   bullet_state = "ready"


 if bullet_state is "fire":
   bulletgay()
   bulletY -= bulletY_change 

 #collision
 collisions = collision(gayX,gayY,bulletX,bulletY)
 if collisions:
   bulletY = 480
   bullet_state = "ready"
 
 

 #gun
 screen.blit(gun,(gunX,gunY))

 pygame.display.update()
pygame.quit()
 